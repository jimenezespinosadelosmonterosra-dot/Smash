"use client";

import { useState } from "react";
import * as XLSX from "xlsx";
import { TRAINING_TYPES, TrainingType } from "@/types";
import { createSession } from "@/services/sessions";

type RawRow = Record<string, any>;

const TARGET_FIELDS = [
  { key: "date", label: "Fecha", required: true },
  { key: "duration_minutes", label: "Duración (min)", required: true },
  { key: "character", label: "Personaje", required: false },
  { key: "training_type", label: "Tipo de entrenamiento", required: false },
  { key: "overall_rating", label: "Valoración", required: false },
  { key: "notes", label: "Notas", required: false },
] as const;

type FieldKey = (typeof TARGET_FIELDS)[number]["key"];

function parseExcelDate(value: any): string | null {
  if (!value) return null;
  if (typeof value === "number") {
    const d = XLSX.SSF.parse_date_code(value);
    if (!d) return null;
    return `${d.y}-${String(d.m).padStart(2, "0")}-${String(d.d).padStart(2, "0")}`;
  }
  const d = new Date(value);
  if (Number.isNaN(d.getTime())) return null;
  return d.toISOString().slice(0, 10);
}

export default function ImportSessions() {
  const [rows, setRows] = useState<RawRow[]>([]);
  const [columns, setColumns] = useState<string[]>([]);
  const [mapping, setMapping] = useState<Partial<Record<FieldKey, string>>>({});
  const [rowErrors, setRowErrors] = useState<Record<number, string>>({});
  const [importing, setImporting] = useState(false);
  const [result, setResult] = useState<{ ok: number; failed: number } | null>(null);
  const [fileName, setFileName] = useState<string | null>(null);

  function handleFile(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    if (!file) return;
    setFileName(file.name);
    setResult(null);
    setRowErrors({});

    const reader = new FileReader();
    reader.onload = (evt) => {
      const data = evt.target?.result;
      const workbook = XLSX.read(data, { type: "binary" });
      const sheet = workbook.Sheets[workbook.SheetNames[0]];
      const json = XLSX.utils.sheet_to_json<RawRow>(sheet, { defval: "" });
      if (json.length === 0) return;

      setColumns(Object.keys(json[0]));
      setRows(json);

      // auto-mapeo por nombre parecido
      const auto: Partial<Record<FieldKey, string>> = {};
      const cols = Object.keys(json[0]);
      const find = (needles: string[]) =>
        cols.find((c) => needles.some((n) => c.toLowerCase().includes(n)));

      auto.date = find(["fecha", "date"]);
      auto.duration_minutes = find(["duraci", "minuto", "duration"]);
      auto.character = find(["personaje", "character", "main"]);
      auto.training_type = find(["tipo", "type"]);
      auto.overall_rating = find(["valoraci", "rating", "puntuaci"]);
      auto.notes = find(["nota", "note"]);
      setMapping(auto);
    };
    reader.readAsBinaryString(file);
  }

  function validateRow(row: RawRow, index: number): string | null {
    const dateCol = mapping.date;
    const durationCol = mapping.duration_minutes;

    if (!dateCol || !row[dateCol]) return "Falta la fecha";
    if (!parseExcelDate(row[dateCol])) return "Fecha no válida";
    if (!durationCol || row[durationCol] === "" || row[durationCol] == null)
      return "Falta la duración";
    if (Number.isNaN(Number(row[durationCol]))) return "Duración no numérica";
    return null;
  }

  async function handleImport() {
    setImporting(true);
    let ok = 0;
    let failed = 0;
    const errors: Record<number, string> = {};

    for (let i = 0; i < rows.length; i++) {
      const row = rows[i];
      const err = validateRow(row, i);
      if (err) {
        errors[i] = err;
        failed++;
        continue;
      }

      const rawType = mapping.training_type ? String(row[mapping.training_type]) : "";
      const matchedType = TRAINING_TYPES.find(
        (t) => t.toLowerCase() === rawType.toLowerCase()
      ) as TrainingType | undefined;

      const { error } = await createSession({
        date: parseExcelDate(row[mapping.date!])!,
        duration_minutes: Number(row[mapping.duration_minutes!]),
        character: mapping.character ? String(row[mapping.character] || "") || null : null,
        training_type: matchedType ?? "General",
        overall_rating: mapping.overall_rating
          ? Number(row[mapping.overall_rating]) || null
          : null,
        notes: mapping.notes ? String(row[mapping.notes] || "") || null : null,
      });

      if (error) {
        errors[i] = error.message ?? "Error al guardar";
        failed++;
      } else {
        ok++;
      }
    }

    setRowErrors(errors);
    setResult({ ok, failed });
    setImporting(false);
  }

  const mappingComplete = mapping.date && mapping.duration_minutes;

  return (
    <div className="card">
      <h3 style={{ marginTop: 0 }}>Importar desde Excel / CSV</h3>
      <p style={{ color: "var(--text-muted)", fontSize: "0.85rem" }}>
        Sube tu tracker existente (.xlsx o .csv), mapea las columnas y previsualiza antes de importar.
      </p>

      <div className="field">
        <label>Archivo</label>
        <input type="file" accept=".xlsx,.xls,.csv" className="input" onChange={handleFile} />
      </div>

      {fileName && rows.length > 0 && (
        <>
          <p style={{ fontSize: "0.82rem", color: "var(--text-muted)" }}>
            {fileName} — {rows.length} filas detectadas
          </p>

          <div style={{ marginBottom: 16 }}>
            <p className="card-title">Mapeo de columnas</p>
            <div className="grid grid-2">
              {TARGET_FIELDS.map((f) => (
                <div className="field" key={f.key}>
                  <label>
                    {f.label} {f.required && <span style={{ color: "var(--danger)" }}>*</span>}
                  </label>
                  <select
                    className="input"
                    value={mapping[f.key] ?? ""}
                    onChange={(e) =>
                      setMapping({ ...mapping, [f.key]: e.target.value || undefined })
                    }
                  >
                    <option value="">— No mapear —</option>
                    {columns.map((c) => (
                      <option key={c} value={c}>
                        {c}
                      </option>
                    ))}
                  </select>
                </div>
              ))}
            </div>
          </div>

          <div className="table-wrap" style={{ maxHeight: 240, overflowY: "auto", marginBottom: 16 }}>
            <table className="data-table">
              <thead>
                <tr>
                  {columns.map((c) => (
                    <th key={c}>{c}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {rows.slice(0, 5).map((r, i) => (
                  <tr key={i}>
                    {columns.map((c) => (
                      <td key={c}>{String(r[c])}</td>
                    ))}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          <button
            className="btn btn-primary"
            disabled={!mappingComplete || importing}
            onClick={handleImport}
          >
            {importing ? "Importando..." : `Importar ${rows.length} filas`}
          </button>

          {result && (
            <div className={`alert ${result.failed > 0 ? "alert-error" : "alert-success"}`} style={{ marginTop: 14 }}>
              Importadas correctamente: {result.ok}. Con errores: {result.failed}.
            </div>
          )}

          {Object.keys(rowErrors).length > 0 && (
            <div className="table-wrap" style={{ marginTop: 10, maxHeight: 160, overflowY: "auto" }}>
              <table className="data-table">
                <thead>
                  <tr>
                    <th>Fila</th>
                    <th>Error</th>
                  </tr>
                </thead>
                <tbody>
                  {Object.entries(rowErrors).map(([i, msg]) => (
                    <tr key={i}>
                      <td>{Number(i) + 1}</td>
                      <td style={{ color: "#ff9d9d" }}>{msg}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </>
      )}
    </div>
  );
}
