"use client";

import { usePathname, useRouter } from "next/navigation";
import { useState } from "react";
import { useAuth } from "@/hooks/useAuth";

const LINKS = [
  { href: "/dashboard", label: "Dashboard", icon: "🏠" },
  { href: "/training", label: "Entrenamiento", icon: "🥊" },
  { href: "/history", label: "Historial", icon: "📋" },
  { href: "/progress", label: "Progreso", icon: "📈" },
  { href: "/goals", label: "Objetivos", icon: "🎯" },
  { href: "/exercises", label: "Ejercicios", icon: "🧩" },
  { href: "/settings", label: "Configuración", icon: "⚙️" },
];

export default function Sidebar() {
  const pathname = usePathname();
  const router = useRouter();
  const { user, signOut } = useAuth();
  const [open, setOpen] = useState(false);

  const initial = (user?.email ?? "?").charAt(0).toUpperCase();

  async function handleSignOut() {
    await signOut();
    router.replace("/login");
  }

  return (
    <>
      <div className="topbar-mobile">
        <span className="sidebar-brand" style={{ padding: 0 }}>
          SMASH TRACKER
        </span>
        <button className="btn btn-secondary btn-sm" onClick={() => setOpen((o) => !o)}>
          {open ? "Cerrar" : "Menú"}
        </button>
      </div>

      <aside className={`sidebar ${open ? "open" : ""}`}>
        <div className="sidebar-brand">SMASH TRACKER</div>
        <nav className="sidebar-nav">
          {LINKS.map((link) => (
            <a
              key={link.href}
              href={link.href}
              className={`sidebar-link ${pathname?.startsWith(link.href) ? "active" : ""}`}
              onClick={() => setOpen(false)}
            >
              <span>{link.icon}</span>
              <span>{link.label}</span>
            </a>
          ))}
        </nav>
        <div className="sidebar-footer">
          <div className="avatar">{initial}</div>
          <div style={{ flex: 1, minWidth: 0 }}>
            <div
              style={{
                fontSize: "0.82rem",
                fontWeight: 600,
                overflow: "hidden",
                textOverflow: "ellipsis",
                whiteSpace: "nowrap",
              }}
              title={user?.email ?? ""}
            >
              {user?.email}
            </div>
          </div>
          <button
            className="btn btn-ghost btn-sm"
            onClick={handleSignOut}
            aria-label="Cerrar sesión"
            title="Cerrar sesión"
          >
            ⏻
          </button>
        </div>
      </aside>
    </>
  );
}
