"use client";

import { useState, FormEvent, useEffect } from "react";
import { useRouter } from "next/navigation";
import { useAuth } from "@/hooks/useAuth";

export default function LoginPage() {
  const { signIn, sendPasswordReset, session, loading } = useAuth();
  const router = useRouter();

  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [info, setInfo] = useState<string | null>(null);
  const [submitting, setSubmitting] = useState(false);
  const [mode, setMode] = useState<"login" | "reset">("login");

  useEffect(() => {
    if (!loading && session) router.replace("/dashboard");
  }, [loading, session, router]);

  async function handleSubmit(e: FormEvent) {
    e.preventDefault();
    setError(null);
    setInfo(null);
    setSubmitting(true);

    if (mode === "login") {
      const { error } = await signIn(email, password);
      setSubmitting(false);
      if (error) {
        setError(
          error.toLowerCase().includes("invalid")
            ? "Email o contraseña incorrectos."
            : error
        );
        return;
      }
      router.replace("/dashboard");
    } else {
      const { error } = await sendPasswordReset(email);
      setSubmitting(false);
      if (error) {
        setError(error);
        return;
      }
      setInfo("Te hemos enviado un email con instrucciones para recuperar tu contraseña.");
    }
  }

  return (
    <div className="auth-wrapper">
      <div className="auth-card">
        <h1 className="auth-title">SMASH TRAINING TRACKER</h1>
        <p className="auth-subtitle">Track your training. Improve your game.</p>

        {error && <div className="alert alert-error">{error}</div>}
        {info && <div className="alert alert-success">{info}</div>}

        <form onSubmit={handleSubmit}>
          <div className="field">
            <label htmlFor="email">Email</label>
            <input
              id="email"
              type="email"
              className="input"
              autoComplete="email"
              required
              value={email}
              onChange={(e) => setEmail(e.target.value)}
            />
          </div>

          {mode === "login" && (
            <div className="field">
              <label htmlFor="password">Contraseña</label>
              <input
                id="password"
                type="password"
                className="input"
                autoComplete="current-password"
                required
                value={password}
                onChange={(e) => setPassword(e.target.value)}
              />
            </div>
          )}

          <button className="btn btn-primary" style={{ width: "100%" }} disabled={submitting}>
            {submitting
              ? "Cargando..."
              : mode === "login"
              ? "Iniciar sesión"
              : "Enviar email de recuperación"}
          </button>
        </form>

        <div style={{ textAlign: "center", marginTop: 16 }}>
          {mode === "login" ? (
            <button
              className="btn btn-ghost btn-sm"
              onClick={() => {
                setMode("reset");
                setError(null);
                setInfo(null);
              }}
            >
              ¿Has olvidado tu contraseña?
            </button>
          ) : (
            <button
              className="btn btn-ghost btn-sm"
              onClick={() => {
                setMode("login");
                setError(null);
                setInfo(null);
              }}
            >
              Volver a iniciar sesión
            </button>
          )}
        </div>
      </div>
    </div>
  );
}
