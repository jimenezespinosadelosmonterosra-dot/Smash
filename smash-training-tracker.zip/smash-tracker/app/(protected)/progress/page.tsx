"use client";

import { useEffect, useMemo, useState } from "react";
import { Line } from "react-chartjs-2";
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Tooltip,
  Legend,
} from "chart.js";
import { listSessions } from "@/services/sessions";
import { TrainingSession } from "@/types";

ChartJS.register(CategoryScale, LinearScale, PointElement, LineElement, Tooltip, Legend);

type RangeKey = "7" | "30" | "90" | "365" | "all";

const RANGES: { key: RangeKey; label: string }[] = [
  { key: "7", label: "7 días" },
  { key: "30", label: "30 días" },
  { key: "90", label: "90 días" },
  { key: "365", label: "1 año" },
  { key: "all", label: "Todo" },
];

const chartOptions = {
  responsive: true,
  maintainAspectRatio: false,
  plugins: {
    legend: { labels: { color: "#9096ab" } },
  },
  scales: {
    x: { ticks: { color: "#5c637a" }, grid: { color: "#232838" } },
    y: { ticks: { color: "#5c637a" }, grid: { color: "#232838" } },
  },
};

export default function ProgressPage() {
  const [range, setRange] = useState<RangeKey>("30");
  const [sessions, setSessions] = useState<TrainingSession[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let mounted = true;
    setLoading(true);

    let from: string | undefined;
    if (range !== "all") {
      const d = new Date();
      d.setDate(d.getDate() - Number(range));
      from = d.toISOString().slice(0, 10);
    }

    listSessions({ page: 0, pageSize: 1000, from }).then(({ data }) => {
      if (!mounted) return;
      setSessions([...data].sort((a, b) => a.date.localeCompare(b.date)));
      setLoading(false);
    });

    return () => {
      mounted = false;
    };
  }, [range]);

  const stats = useMemo(() => {
    const totalSessions = sessions.length;
    const totalMinutes = sessions.reduce((s, x) => s + x.duration_minutes, 0);
    const avgDuration = totalSessions ? Math.round(totalMinutes / totalSessions) : 0;
    const ratings = sessions.filter((s) => s.overall_rating != null).map((s) => s.overall_rating!);
    const bestRating = ratings.length ? Math.max(...ratings) : 0;

    const now = new Date();
    const startOfWeek = new Date(now);
    startOfWeek.setDate(now.getDate() - now.getDay());
    const startOfMonth = new Date(now.getFullYear(), now.getMonth(), 1);

    const sessionsThisWeek = sessions.filter((s) => new Date(s.date) >= startOfWeek).length;
    const sessionsThisMonth = sessions.filter((s) => new Date(s.date) >= startOfMonth).length;

    return { totalSessions, totalMinutes, avgDuration, bestRating, sessionsThisWeek, sessionsThisMonth };
  }, [sessions]);

  const labels = sessions.map((s) => new Date(s.date).toLocaleDateString("es-ES", { day: "2-digit", month: "2-digit" }));

  const durationData = {
    labels,
    datasets: [
      {
        label: "Minutos entrenados",
        data: sessions.map((s) => s.duration_minutes),
        borderColor: "#6c5ce7",
        backgroundColor: "rgba(108,92,231,0.2)",
        tension: 0.3,
      },
    ],
  };

  const ratingData = {
    labels,
    datasets: [
      {
        label: "Valoración de la sesión",
        data: sessions.map((s) => s.overall_rating ?? null),
        borderColor: "#00d4ff",
        backgroundColor: "rgba(0,212,255,0.2)",
        tension: 0.3,
      },
    ],
  };

  return (
    <div>
      <div className="page-header">
        <div>
          <h1 className="page-title">Progreso</h1>
          <p className="page-subtitle">Evolución de tu entrenamiento a lo largo del tiempo</p>
        </div>
      </div>

      <div className="filters-row">
        {RANGES.map((r) => (
          <button
            key={r.key}
            className={`btn btn-sm ${range === r.key ? "btn-primary" : "btn-secondary"}`}
            onClick={() => setRange(r.key)}
          >
            {r.label}
          </button>
        ))}
      </div>

      {loading ? (
        <div className="skeleton" style={{ height: 300, marginBottom: 20 }} />
      ) : sessions.length === 0 ? (
        <div className="card empty-state">
          <p>No hay sesiones en este rango de fechas todavía.</p>
        </div>
      ) : (
        <>
          <div className="grid grid-4" style={{ marginBottom: 18 }}>
            <div className="card">
              <p className="card-title">Sesiones totales</p>
              <p className="card-value">{stats.totalSessions}</p>
            </div>
            <div className="card">
              <p className="card-title">Horas totales</p>
              <p className="card-value">{(stats.totalMinutes / 60).toFixed(1)}h</p>
            </div>
            <div className="card">
              <p className="card-title">Media / sesión</p>
              <p className="card-value">{stats.avgDuration} min</p>
            </div>
            <div className="card">
              <p className="card-title">Mejor valoración</p>
              <p className="card-value">{stats.bestRating || "—"}</p>
            </div>
          </div>

          <div className="grid grid-2">
            <div className="card" style={{ height: 320 }}>
              <p className="card-title">Volumen de entrenamiento</p>
              <div style={{ height: 250 }}>
                <Line data={durationData} options={chartOptions} />
              </div>
            </div>
            <div className="card" style={{ height: 320 }}>
              <p className="card-title">Evolución de puntuaciones</p>
              <div style={{ height: 250 }}>
                <Line data={ratingData} options={chartOptions} />
              </div>
            </div>
          </div>
        </>
      )}
    </div>
  );
}
