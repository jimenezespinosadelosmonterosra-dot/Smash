"use client";

import { useState, FormEvent } from "react";
import Papa from "papaparse";
import { useAuth } from "@/hooks/useAuth";
import { supabase } from "@/lib/supabaseClient";
import { listSessions } from "@/services/sessions";
import ImportSessions from "@/components/ImportSessions";

export default function SettingsPage() {
  const { user, updatePassword, signOut } = useAuth();
  const [displayName, setDisplayName] = useState("");
  const [savingName, setSavingName] = useState(false);
  const [nameMsg, setNameMsg] = useState<string | null>(null);

  const [newPassword, setNewPassword] = useState("");
  const [passwordMsg, setPasswordMsg] = useState<string | null>(null);
  const [passwordError, setPasswordError] = useState<string | null>(null);
  const [savingPassword, setSavingPassword] = useState(false);

  const [exporting, setExporting] = useState(false);

  async function handleSaveName(e: FormEvent) {
    e.preventDefault();
    setNameMsg(null);
    setSavingName(true);
    const { error } = await supabase
      .from("profiles")
      .update({ display_name: displayName })
      .eq("id", user?.id);
    setSavingName(false);
    setNameMsg(error ? "No se pudo actualizar el nombre." : "Nombre actualizado.");
  }

  async function handleChangePassword(e: FormEvent) {
    e.preventDefault();
    setPasswordError(null);
    setPasswordMsg(null);

    if (newPassword.length < 8) {
      setPasswordError("La contraseña debe tener al menos 8 caracteres.");
      return;
    }

    setSavingPassword(true);
    const { error } = await updatePassword(newPassword);
    setSavingPassword(false);

    if (error) {
      setPasswordError(error);
      return;
    }
    setPasswordMsg("Contraseña actualizada correctamente.");
    setNewPassword("");
  }

  async function handleExport(format: "csv" | "json") {
    setExporting(true);
    const { data } = await listSessions({ page: 0, pageSize: 5000 });
    setExporting(false);

    const filename = `smash-training-sessions.${format}`;
    let blob: Blob;

    if (format === "json") {
      blob = new Blob([JSON.stringify(data, null, 2)], { type: "application/json" });
    } else {
      const csv = Papa.unparse(data);
      blob = new Blob([csv], { type: "text/csv" });
    }

    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = filename;
    a.click();
    URL.revokeObjectURL(url);
  }

  async function handleBackup() {
    setExporting(true);
    const [sessions, exercises, goals, statistics] = await Promise.all([
      supabase.from("training_sessions").select("*"),
      supabase.from("exercises").select("*"),
      supabase.from("goals").select("*"),
      supabase.from("statistics").select("*"),
    ]);
    setExporting(false);

    const backup = {
      exported_at: new Date().toISOString(),
      sessions: sessions.data ?? [],
      exercises: exercises.data ?? [],
      goals: goals.data ?? [],
      statistics: statistics.data ?? [],
    };

    const blob = new Blob([JSON.stringify(backup, null, 2)], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `smash-training-backup-${new Date().toISOString().slice(0, 10)}.json`;
    a.click();
    URL.revokeObjectURL(url);
  }

  return (
    <div>
      <div className="page-header">
        <div>
          <h1 className="page-title">Configuración</h1>
          <p className="page-subtitle">Gestiona tu cuenta y tus datos</p>
        </div>
      </div>

      <div className="grid grid-2" style={{ alignItems: "start" }}>
        <div className="card">
          <h3 style={{ marginTop: 0 }}>Perfil</h3>
          <p style={{ color: "var(--text-muted)", fontSize: "0.85rem" }}>Email: {user?.email}</p>
          {nameMsg && <div className="alert alert-success">{nameMsg}</div>}
          <form onSubmit={handleSaveName}>
            <div className="field">
              <label>Nombre para mostrar</label>
              <input
                className="input"
                placeholder="Tu nombre"
                value={displayName}
                onChange={(e) => setDisplayName(e.target.value)}
              />
            </div>
            <button className="btn btn-secondary" disabled={savingName}>
              {savingName ? "Guardando..." : "Guardar cambios"}
            </button>
          </form>
        </div>

        <div className="card">
          <h3 style={{ marginTop: 0 }}>Cambiar contraseña</h3>
          {passwordError && <div className="alert alert-error">{passwordError}</div>}
          {passwordMsg && <div className="alert alert-success">{passwordMsg}</div>}
          <form onSubmit={handleChangePassword}>
            <div className="field">
              <label>Nueva contraseña</label>
              <input
                type="password"
                className="input"
                value={newPassword}
                onChange={(e) => setNewPassword(e.target.value)}
              />
            </div>
            <button className="btn btn-secondary" disabled={savingPassword}>
              {savingPassword ? "Guardando..." : "Actualizar contraseña"}
            </button>
          </form>
        </div>

        <div className="card">
          <h3 style={{ marginTop: 0 }}>Exportar datos</h3>
          <p style={{ color: "var(--text-muted)", fontSize: "0.85rem" }}>
            Descarga tus sesiones de entrenamiento.
          </p>
          <div style={{ display: "flex", gap: 10 }}>
            <button className="btn btn-secondary" disabled={exporting} onClick={() => handleExport("csv")}>
              Exportar CSV
            </button>
            <button className="btn btn-secondary" disabled={exporting} onClick={() => handleExport("json")}>
              Exportar JSON
            </button>
          </div>
        </div>

        <div className="card">
          <h3 style={{ marginTop: 0 }}>Backup completo</h3>
          <p style={{ color: "var(--text-muted)", fontSize: "0.85rem" }}>
            Descarga todos tus datos (sesiones, ejercicios, objetivos, estadísticas) en un único JSON.
          </p>
          <button className="btn btn-secondary" disabled={exporting} onClick={handleBackup}>
            {exporting ? "Generando..." : "Exportar backup"}
          </button>
        </div>

        <div className="card" style={{ borderColor: "rgba(239,68,68,0.3)" }}>
          <h3 style={{ marginTop: 0 }}>Sesión</h3>
          <button className="btn btn-danger" onClick={signOut}>
            Cerrar sesión
          </button>
        </div>
      </div>

      <div style={{ marginTop: 18 }}>
        <ImportSessions />
      </div>
    </div>
  );
}
