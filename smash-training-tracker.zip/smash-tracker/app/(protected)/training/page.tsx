"use client";

import { useState, FormEvent } from "react";
import { useRouter } from "next/navigation";
import { createSession } from "@/services/sessions";
import { TRAINING_TYPES, TrainingType } from "@/types";

export default function TrainingPage() {
  const router = useRouter();
  const [date, setDate] = useState(() => new Date().toISOString().slice(0, 10));
  const [duration, setDuration] = useState("60");
  const [character, setCharacter] = useState("");
  const [trainingType, setTrainingType] = useState<TrainingType>("General");
  const [rating, setRating] = useState("5");
  const [notes, setNotes] = useState("");
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState(false);

  async function handleSubmit(e: FormEvent) {
    e.preventDefault();
    setError(null);
    setSuccess(false);

    const durationNum = Number(duration);
    const ratingNum = Number(rating);

    if (!date) {
      setError("La fecha es obligatoria.");
      return;
    }
    if (Number.isNaN(durationNum) || durationNum < 0) {
      setError("La duración debe ser un número igual o mayor que 0.");
      return;
    }
    if (Number.isNaN(ratingNum) || ratingNum < 1 || ratingNum > 10) {
      setError("La valoración debe estar entre 1 y 10.");
      return;
    }

    setSubmitting(true);
    const { error } = await createSession({
      date,
      duration_minutes: durationNum,
      character: character || null,
      training_type: trainingType,
      overall_rating: ratingNum,
      notes: notes || null,
    });
    setSubmitting(false);

    if (error) {
      setError(error.message ?? "No se pudo guardar la sesión.");
      return;
    }

    setSuccess(true);
    setNotes("");
    setTimeout(() => setSuccess(false), 2500);
  }

  return (
    <div>
      <div className="page-header">
        <div>
          <h1 className="page-title">Nueva sesión de entrenamiento</h1>
          <p className="page-subtitle">Registra los datos de tu sesión de hoy</p>
        </div>
      </div>

      <div className="card" style={{ maxWidth: 560 }}>
        {error && <div className="alert alert-error">{error}</div>}
        {success && <div className="alert alert-success">Sesión guardada correctamente.</div>}

        <form onSubmit={handleSubmit}>
          <div className="field">
            <label htmlFor="date">Fecha</label>
            <input
              id="date"
              type="date"
              className="input"
              required
              value={date}
              onChange={(e) => setDate(e.target.value)}
            />
          </div>

          <div className="field">
            <label htmlFor="duration">Duración (minutos)</label>
            <input
              id="duration"
              type="number"
              min={0}
              className="input"
              required
              value={duration}
              onChange={(e) => setDuration(e.target.value)}
            />
          </div>

          <div className="field">
            <label htmlFor="character">Personaje</label>
            <input
              id="character"
              type="text"
              className="input"
              placeholder="Ej. Fox, Marth, Sonic..."
              value={character}
              onChange={(e) => setCharacter(e.target.value)}
            />
          </div>

          <div className="field">
            <label htmlFor="type">Tipo de entrenamiento</label>
            <select
              id="type"
              className="input"
              value={trainingType}
              onChange={(e) => setTrainingType(e.target.value as TrainingType)}
            >
              {TRAINING_TYPES.map((t) => (
                <option key={t} value={t}>
                  {t}
                </option>
              ))}
            </select>
          </div>

          <div className="field">
            <label htmlFor="rating">Valoración (1-10)</label>
            <input
              id="rating"
              type="number"
              min={1}
              max={10}
              className="input"
              required
              value={rating}
              onChange={(e) => setRating(e.target.value)}
            />
          </div>

          <div className="field">
            <label htmlFor="notes">Notas</label>
            <textarea
              id="notes"
              className="input"
              placeholder="¿Qué tal fue la sesión?"
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
            />
          </div>

          <div style={{ display: "flex", gap: 10 }}>
            <button className="btn btn-primary" disabled={submitting}>
              {submitting ? "Guardando..." : "Guardar sesión"}
            </button>
            <button
              type="button"
              className="btn btn-secondary"
              onClick={() => router.push("/history")}
            >
              Ver historial
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
