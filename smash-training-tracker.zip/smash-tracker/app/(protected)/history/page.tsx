"use client";

import { useEffect, useState, useCallback } from "react";
import Link from "next/link";
import {
  listSessions,
  deleteSession,
  updateSession,
} from "@/services/sessions";
import { TRAINING_TYPES, TrainingSession, TrainingType } from "@/types";

const PAGE_SIZE = 15;

export default function HistoryPage() {
  const [sessions, setSessions] = useState<TrainingSession[]>([]);
  const [loading, setLoading] = useState(true);
  const [page, setPage] = useState(0);
  const [total, setTotal] = useState(0);
  const [search, setSearch] = useState("");
  const [typeFilter, setTypeFilter] = useState("");
  const [editing, setEditing] = useState<TrainingSession | null>(null);
  const [confirmDelete, setConfirmDelete] = useState<string | null>(null);

  const load = useCallback(async () => {
    setLoading(true);
    const { data, count } = await listSessions({
      page,
      pageSize: PAGE_SIZE,
      trainingType: typeFilter || undefined,
      search: search || undefined,
    });
    setSessions(data);
    setTotal(count);
    setLoading(false);
  }, [page, typeFilter, search]);

  useEffect(() => {
    load();
  }, [load]);

  async function handleDelete(id: string) {
    await deleteSession(id);
    setConfirmDelete(null);
    load();
  }

  async function handleSaveEdit() {
    if (!editing) return;
    await updateSession(editing.id, {
      date: editing.date,
      duration_minutes: editing.duration_minutes,
      character: editing.character,
      training_type: editing.training_type,
      overall_rating: editing.overall_rating,
      notes: editing.notes,
    });
    setEditing(null);
    load();
  }

  const totalPages = Math.max(1, Math.ceil(total / PAGE_SIZE));

  return (
    <div>
      <div className="page-header">
        <div>
          <h1 className="page-title">Historial</h1>
          <p className="page-subtitle">Todas tus sesiones registradas</p>
        </div>
        <Link href="/training" className="btn btn-primary">
          + Nueva sesión
        </Link>
      </div>

      <div className="filters-row">
        <input
          className="input"
          placeholder="Buscar en notas..."
          value={search}
          onChange={(e) => {
            setPage(0);
            setSearch(e.target.value);
          }}
        />
        <select
          className="input"
          value={typeFilter}
          onChange={(e) => {
            setPage(0);
            setTypeFilter(e.target.value);
          }}
        >
          <option value="">Todos los tipos</option>
          {TRAINING_TYPES.map((t) => (
            <option key={t} value={t}>
              {t}
            </option>
          ))}
        </select>
      </div>

      <div className="card">
        {loading ? (
          <div className="skeleton" style={{ height: 200 }} />
        ) : sessions.length === 0 ? (
          <div className="empty-state">
            <p>No hay sesiones que coincidan con estos filtros.</p>
          </div>
        ) : (
          <div className="table-wrap">
            <table className="data-table">
              <thead>
                <tr>
                  <th>Fecha</th>
                  <th>Duración</th>
                  <th>Personaje</th>
                  <th>Tipo</th>
                  <th>Valoración</th>
                  <th>Notas</th>
                  <th></th>
                </tr>
              </thead>
              <tbody>
                {sessions.map((s) => (
                  <tr key={s.id}>
                    <td>{new Date(s.date).toLocaleDateString("es-ES")}</td>
                    <td>{s.duration_minutes} min</td>
                    <td>{s.character || "—"}</td>
                    <td>
                      <span className="badge">{s.training_type}</span>
                    </td>
                    <td>{s.overall_rating ? `${s.overall_rating}/10` : "—"}</td>
                    <td
                      style={{
                        maxWidth: 200,
                        overflow: "hidden",
                        textOverflow: "ellipsis",
                        whiteSpace: "nowrap",
                      }}
                      title={s.notes ?? ""}
                    >
                      {s.notes || "—"}
                    </td>
                    <td>
                      <div style={{ display: "flex", gap: 6 }}>
                        <button className="btn btn-secondary btn-sm" onClick={() => setEditing(s)}>
                          Editar
                        </button>
                        <button
                          className="btn btn-danger btn-sm"
                          onClick={() => setConfirmDelete(s.id)}
                        >
                          Eliminar
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}

        {totalPages > 1 && (
          <div style={{ display: "flex", justifyContent: "center", gap: 10, marginTop: 16 }}>
            <button
              className="btn btn-secondary btn-sm"
              disabled={page === 0}
              onClick={() => setPage((p) => p - 1)}
            >
              Anterior
            </button>
            <span style={{ alignSelf: "center", fontSize: "0.85rem", color: "var(--text-muted)" }}>
              Página {page + 1} de {totalPages}
            </span>
            <button
              className="btn btn-secondary btn-sm"
              disabled={page >= totalPages - 1}
              onClick={() => setPage((p) => p + 1)}
            >
              Siguiente
            </button>
          </div>
        )}
      </div>

      {editing && (
        <div className="modal-backdrop" onClick={() => setEditing(null)}>
          <div className="modal" onClick={(e) => e.stopPropagation()}>
            <h3 style={{ marginTop: 0 }}>Editar sesión</h3>
            <div className="field">
              <label>Fecha</label>
              <input
                type="date"
                className="input"
                value={editing.date}
                onChange={(e) => setEditing({ ...editing, date: e.target.value })}
              />
            </div>
            <div className="field">
              <label>Duración (minutos)</label>
              <input
                type="number"
                min={0}
                className="input"
                value={editing.duration_minutes}
                onChange={(e) =>
                  setEditing({ ...editing, duration_minutes: Number(e.target.value) })
                }
              />
            </div>
            <div className="field">
              <label>Personaje</label>
              <input
                type="text"
                className="input"
                value={editing.character ?? ""}
                onChange={(e) => setEditing({ ...editing, character: e.target.value })}
              />
            </div>
            <div className="field">
              <label>Tipo</label>
              <select
                className="input"
                value={editing.training_type}
                onChange={(e) =>
                  setEditing({ ...editing, training_type: e.target.value as TrainingType })
                }
              >
                {TRAINING_TYPES.map((t) => (
                  <option key={t} value={t}>
                    {t}
                  </option>
                ))}
              </select>
            </div>
            <div className="field">
              <label>Valoración</label>
              <input
                type="number"
                min={1}
                max={10}
                className="input"
                value={editing.overall_rating ?? ""}
                onChange={(e) =>
                  setEditing({ ...editing, overall_rating: Number(e.target.value) })
                }
              />
            </div>
            <div className="field">
              <label>Notas</label>
              <textarea
                className="input"
                value={editing.notes ?? ""}
                onChange={(e) => setEditing({ ...editing, notes: e.target.value })}
              />
            </div>
            <div style={{ display: "flex", gap: 10, justifyContent: "flex-end" }}>
              <button className="btn btn-ghost" onClick={() => setEditing(null)}>
                Cancelar
              </button>
              <button className="btn btn-primary" onClick={handleSaveEdit}>
                Guardar cambios
              </button>
            </div>
          </div>
        </div>
      )}

      {confirmDelete && (
        <div className="modal-backdrop" onClick={() => setConfirmDelete(null)}>
          <div className="modal" onClick={(e) => e.stopPropagation()} style={{ maxWidth: 380 }}>
            <h3 style={{ marginTop: 0 }}>¿Eliminar esta sesión?</h3>
            <p style={{ color: "var(--text-muted)" }}>Esta acción no se puede deshacer.</p>
            <div style={{ display: "flex", gap: 10, justifyContent: "flex-end" }}>
              <button className="btn btn-ghost" onClick={() => setConfirmDelete(null)}>
                Cancelar
              </button>
              <button className="btn btn-danger" onClick={() => handleDelete(confirmDelete)}>
                Eliminar
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
