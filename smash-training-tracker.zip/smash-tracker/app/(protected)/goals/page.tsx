"use client";

import { useEffect, useState, FormEvent, useCallback } from "react";
import { listGoals, createGoal, updateGoal, deleteGoal } from "@/services/goals";
import { Goal } from "@/types";

const emptyForm = {
  title: "",
  description: "",
  target_value: "",
  unit: "",
  deadline: "",
};

export default function GoalsPage() {
  const [goals, setGoals] = useState<Goal[]>([]);
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [form, setForm] = useState(emptyForm);
  const [error, setError] = useState<string | null>(null);
  const [submitting, setSubmitting] = useState(false);
  const [celebrate, setCelebrate] = useState<string | null>(null);

  const load = useCallback(async () => {
    setLoading(true);
    const { data } = await listGoals();
    setGoals(data);
    setLoading(false);
  }, []);

  useEffect(() => {
    load();
  }, [load]);

  async function handleCreate(e: FormEvent) {
    e.preventDefault();
    setError(null);

    const target = Number(form.target_value);
    if (!form.title.trim()) {
      setError("El título es obligatorio.");
      return;
    }
    if (Number.isNaN(target) || target <= 0) {
      setError("El valor objetivo debe ser un número mayor que 0.");
      return;
    }

    setSubmitting(true);
    const { error } = await createGoal({
      title: form.title,
      description: form.description || null,
      target_value: target,
      unit: form.unit || null,
      deadline: form.deadline || null,
    });
    setSubmitting(false);

    if (error) {
      setError(error.message ?? "No se pudo crear el objetivo.");
      return;
    }

    setForm(emptyForm);
    setShowForm(false);
    load();
  }

  async function handleProgress(goal: Goal, delta: number) {
    const newValue = Math.max(0, goal.current_value + delta);
    const wasIncomplete = !goal.completed;
    const { data } = await updateGoal(goal.id, { current_value: newValue });
    if (data?.completed && wasIncomplete) {
      setCelebrate(goal.id);
      setTimeout(() => setCelebrate(null), 2000);
    }
    load();
  }

  async function handleDelete(id: string) {
    await deleteGoal(id);
    load();
  }

  return (
    <div>
      <div className="page-header">
        <div>
          <h1 className="page-title">Objetivos</h1>
          <p className="page-subtitle">Define y sigue tus metas de entrenamiento</p>
        </div>
        <button className="btn btn-primary" onClick={() => setShowForm((s) => !s)}>
          {showForm ? "Cancelar" : "+ Nuevo objetivo"}
        </button>
      </div>

      {showForm && (
        <div className="card" style={{ maxWidth: 520, marginBottom: 20 }}>
          {error && <div className="alert alert-error">{error}</div>}
          <form onSubmit={handleCreate}>
            <div className="field">
              <label>Título</label>
              <input
                className="input"
                placeholder="Ej. Conseguir 10 sesiones este mes"
                value={form.title}
                onChange={(e) => setForm({ ...form, title: e.target.value })}
              />
            </div>
            <div className="field">
              <label>Descripción</label>
              <textarea
                className="input"
                value={form.description}
                onChange={(e) => setForm({ ...form, description: e.target.value })}
              />
            </div>
            <div className="grid grid-2">
              <div className="field">
                <label>Valor objetivo</label>
                <input
                  type="number"
                  className="input"
                  value={form.target_value}
                  onChange={(e) => setForm({ ...form, target_value: e.target.value })}
                />
              </div>
              <div className="field">
                <label>Unidad</label>
                <input
                  className="input"
                  placeholder="sesiones, horas, repeticiones..."
                  value={form.unit}
                  onChange={(e) => setForm({ ...form, unit: e.target.value })}
                />
              </div>
            </div>
            <div className="field">
              <label>Fecha límite</label>
              <input
                type="date"
                className="input"
                value={form.deadline}
                onChange={(e) => setForm({ ...form, deadline: e.target.value })}
              />
            </div>
            <button className="btn btn-primary" disabled={submitting}>
              {submitting ? "Guardando..." : "Crear objetivo"}
            </button>
          </form>
        </div>
      )}

      {loading ? (
        <div className="skeleton" style={{ height: 200 }} />
      ) : goals.length === 0 ? (
        <div className="card empty-state">
          <p>Todavía no has definido ningún objetivo.</p>
        </div>
      ) : (
        <div className="grid grid-2">
          {goals.map((g) => {
            const pct = Math.min(100, Math.round((g.current_value / g.target_value) * 100));
            return (
              <div key={g.id} className="card" style={{ position: "relative" }}>
                {celebrate === g.id && (
                  <div
                    style={{
                      position: "absolute",
                      top: 12,
                      right: 12,
                      fontSize: "1.4rem",
                    }}
                  >
                    🎉
                  </div>
                )}
                <div style={{ display: "flex", justifyContent: "space-between", alignItems: "start" }}>
                  <div>
                    <h3 style={{ margin: "0 0 4px" }}>{g.title}</h3>
                    {g.description && (
                      <p style={{ color: "var(--text-muted)", fontSize: "0.85rem", margin: 0 }}>
                        {g.description}
                      </p>
                    )}
                  </div>
                  <span className={`badge ${g.completed ? "badge-success" : ""}`}>
                    {g.completed ? "Completado" : "En progreso"}
                  </span>
                </div>

                <div style={{ margin: "16px 0 8px" }}>
                  <div className="progress-track">
                    <div className="progress-fill" style={{ width: `${pct}%` }} />
                  </div>
                  <div
                    style={{
                      display: "flex",
                      justifyContent: "space-between",
                      fontSize: "0.8rem",
                      color: "var(--text-muted)",
                      marginTop: 6,
                    }}
                  >
                    <span>
                      {g.current_value} / {g.target_value} {g.unit ?? ""}
                    </span>
                    <span>{pct}%</span>
                  </div>
                </div>

                {g.deadline && (
                  <p style={{ fontSize: "0.8rem", color: "var(--text-muted)" }}>
                    Fecha límite: {new Date(g.deadline).toLocaleDateString("es-ES")}
                  </p>
                )}

                <div style={{ display: "flex", gap: 8, marginTop: 10 }}>
                  <button className="btn btn-secondary btn-sm" onClick={() => handleProgress(g, 1)}>
                    +1
                  </button>
                  <button className="btn btn-secondary btn-sm" onClick={() => handleProgress(g, -1)}>
                    -1
                  </button>
                  <button
                    className="btn btn-danger btn-sm"
                    style={{ marginLeft: "auto" }}
                    onClick={() => handleDelete(g.id)}
                  >
                    Eliminar
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}
