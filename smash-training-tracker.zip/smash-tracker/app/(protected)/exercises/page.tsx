"use client";

import { useEffect, useState, FormEvent, useCallback } from "react";
import {
  listExercises,
  createExercise,
  updateExercise,
  deleteExercise,
} from "@/services/exercises";
import { Exercise } from "@/types";

const emptyForm = { name: "", category: "", description: "", difficulty: "3" };

export default function ExercisesPage() {
  const [exercises, setExercises] = useState<Exercise[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState("");
  const [categoryFilter, setCategoryFilter] = useState("");
  const [showForm, setShowForm] = useState(false);
  const [editing, setEditing] = useState<Exercise | null>(null);
  const [form, setForm] = useState(emptyForm);
  const [error, setError] = useState<string | null>(null);
  const [submitting, setSubmitting] = useState(false);
  const [confirmDelete, setConfirmDelete] = useState<string | null>(null);

  const load = useCallback(async () => {
    setLoading(true);
    const { data } = await listExercises({
      search: search || undefined,
      category: categoryFilter || undefined,
    });
    setExercises(data);
    setLoading(false);
  }, [search, categoryFilter]);

  useEffect(() => {
    load();
  }, [load]);

  const categories = Array.from(new Set(exercises.map((e) => e.category).filter(Boolean))) as string[];

  function startEdit(ex: Exercise) {
    setEditing(ex);
    setForm({
      name: ex.name,
      category: ex.category ?? "",
      description: ex.description ?? "",
      difficulty: String(ex.difficulty ?? 3),
    });
    setShowForm(true);
  }

  function startNew() {
    setEditing(null);
    setForm(emptyForm);
    setShowForm(true);
  }

  async function handleSubmit(e: FormEvent) {
    e.preventDefault();
    setError(null);

    if (!form.name.trim()) {
      setError("El nombre del ejercicio es obligatorio.");
      return;
    }

    const difficulty = Number(form.difficulty);
    const payload = {
      name: form.name,
      category: form.category || null,
      description: form.description || null,
      difficulty: Number.isNaN(difficulty) ? null : difficulty,
    };

    setSubmitting(true);
    const { error } = editing
      ? await updateExercise(editing.id, payload)
      : await createExercise(payload);
    setSubmitting(false);

    if (error) {
      setError(error.message ?? "No se pudo guardar el ejercicio.");
      return;
    }

    setShowForm(false);
    setEditing(null);
    setForm(emptyForm);
    load();
  }

  async function handleDelete(id: string) {
    await deleteExercise(id);
    setConfirmDelete(null);
    load();
  }

  return (
    <div>
      <div className="page-header">
        <div>
          <h1 className="page-title">Ejercicios</h1>
          <p className="page-subtitle">Tu catálogo personal de ejercicios de entrenamiento</p>
        </div>
        <button className="btn btn-primary" onClick={startNew}>
          + Nuevo ejercicio
        </button>
      </div>

      <div className="filters-row">
        <input
          className="input"
          placeholder="Buscar ejercicio..."
          value={search}
          onChange={(e) => setSearch(e.target.value)}
        />
        <select
          className="input"
          value={categoryFilter}
          onChange={(e) => setCategoryFilter(e.target.value)}
        >
          <option value="">Todas las categorías</option>
          {categories.map((c) => (
            <option key={c} value={c}>
              {c}
            </option>
          ))}
        </select>
      </div>

      {loading ? (
        <div className="skeleton" style={{ height: 200 }} />
      ) : exercises.length === 0 ? (
        <div className="card empty-state">
          <p>Todavía no tienes ejercicios registrados.</p>
        </div>
      ) : (
        <div className="grid grid-2">
          {exercises.map((ex) => (
            <div key={ex.id} className="card">
              <div style={{ display: "flex", justifyContent: "space-between" }}>
                <h3 style={{ margin: "0 0 6px" }}>{ex.name}</h3>
                {ex.category && <span className="badge">{ex.category}</span>}
              </div>
              {ex.description && (
                <p style={{ color: "var(--text-muted)", fontSize: "0.88rem" }}>{ex.description}</p>
              )}
              {ex.difficulty && (
                <p style={{ fontSize: "0.8rem", color: "var(--text-faint)" }}>
                  Dificultad: {"★".repeat(ex.difficulty)}
                  {"☆".repeat(5 - ex.difficulty)}
                </p>
              )}
              <div style={{ display: "flex", gap: 8, marginTop: 10 }}>
                <button className="btn btn-secondary btn-sm" onClick={() => startEdit(ex)}>
                  Editar
                </button>
                <button className="btn btn-danger btn-sm" onClick={() => setConfirmDelete(ex.id)}>
                  Eliminar
                </button>
              </div>
            </div>
          ))}
        </div>
      )}

      {showForm && (
        <div className="modal-backdrop" onClick={() => setShowForm(false)}>
          <div className="modal" onClick={(e) => e.stopPropagation()}>
            <h3 style={{ marginTop: 0 }}>{editing ? "Editar ejercicio" : "Nuevo ejercicio"}</h3>
            {error && <div className="alert alert-error">{error}</div>}
            <form onSubmit={handleSubmit}>
              <div className="field">
                <label>Nombre</label>
                <input
                  className="input"
                  value={form.name}
                  onChange={(e) => setForm({ ...form, name: e.target.value })}
                />
              </div>
              <div className="field">
                <label>Categoría</label>
                <input
                  className="input"
                  placeholder="Movimiento, Recovery, Combos..."
                  value={form.category}
                  onChange={(e) => setForm({ ...form, category: e.target.value })}
                />
              </div>
              <div className="field">
                <label>Descripción</label>
                <textarea
                  className="input"
                  value={form.description}
                  onChange={(e) => setForm({ ...form, description: e.target.value })}
                />
              </div>
              <div className="field">
                <label>Dificultad (1-5)</label>
                <input
                  type="number"
                  min={1}
                  max={5}
                  className="input"
                  value={form.difficulty}
                  onChange={(e) => setForm({ ...form, difficulty: e.target.value })}
                />
              </div>
              <div style={{ display: "flex", gap: 10, justifyContent: "flex-end" }}>
                <button type="button" className="btn btn-ghost" onClick={() => setShowForm(false)}>
                  Cancelar
                </button>
                <button className="btn btn-primary" disabled={submitting}>
                  {submitting ? "Guardando..." : "Guardar"}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {confirmDelete && (
        <div className="modal-backdrop" onClick={() => setConfirmDelete(null)}>
          <div className="modal" onClick={(e) => e.stopPropagation()} style={{ maxWidth: 380 }}>
            <h3 style={{ marginTop: 0 }}>¿Eliminar este ejercicio?</h3>
            <p style={{ color: "var(--text-muted)" }}>
              También se eliminarán sus registros asociados. Esta acción no se puede deshacer.
            </p>
            <div style={{ display: "flex", gap: 10, justifyContent: "flex-end" }}>
              <button className="btn btn-ghost" onClick={() => setConfirmDelete(null)}>
                Cancelar
              </button>
              <button className="btn btn-danger" onClick={() => handleDelete(confirmDelete)}>
                Eliminar
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
