"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { getDashboardSummary } from "@/services/dashboard";

interface Summary {
  totalSessions: number;
  totalMinutes: number;
  weekMinutes: number;
  monthMinutes: number;
  exerciseLogCount: number;
  goalsCompleted: number;
  goalsPending: number;
  recentSessions: { id: string; date: string; duration_minutes: number; overall_rating: number | null }[];
}

function formatHours(minutes: number) {
  const h = Math.floor(minutes / 60);
  const m = minutes % 60;
  if (h === 0) return `${m} min`;
  return `${h}h ${m}m`;
}

export default function DashboardPage() {
  const [summary, setSummary] = useState<Summary | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    let mounted = true;
    getDashboardSummary().then(({ data, error }) => {
      if (!mounted) return;
      if (error) setError("No se pudieron cargar los datos del dashboard.");
      else setSummary(data as Summary);
      setLoading(false);
    });
    return () => {
      mounted = false;
    };
  }, []);

  return (
    <div>
      <div className="page-header">
        <div>
          <h1 className="page-title">Dashboard</h1>
          <p className="page-subtitle">Resumen general de tu entrenamiento</p>
        </div>
        <Link href="/training" className="btn btn-primary">
          + Nueva sesión
        </Link>
      </div>

      {error && <div className="alert alert-error">{error}</div>}

      {loading ? (
        <div className="grid grid-4">
          {[0, 1, 2, 3].map((i) => (
            <div key={i} className="card">
              <div className="skeleton" style={{ height: 14, width: "60%", marginBottom: 12 }} />
              <div className="skeleton" style={{ height: 28, width: "40%" }} />
            </div>
          ))}
        </div>
      ) : summary && summary.totalSessions === 0 ? (
        <div className="card empty-state">
          <p style={{ fontSize: "1.1rem", marginBottom: 16 }}>No hay sesiones todavía.</p>
          <Link href="/training" className="btn btn-primary">
            Registrar primera sesión
          </Link>
        </div>
      ) : summary ? (
        <>
          <div className="grid grid-4" style={{ marginBottom: 18 }}>
            <div className="card">
              <p className="card-title">Sesiones totales</p>
              <p className="card-value">{summary.totalSessions}</p>
            </div>
            <div className="card">
              <p className="card-title">Tiempo total</p>
              <p className="card-value">{formatHours(summary.totalMinutes)}</p>
            </div>
            <div className="card">
              <p className="card-title">Esta semana</p>
              <p className="card-value">{formatHours(summary.weekMinutes)}</p>
            </div>
            <div className="card">
              <p className="card-title">Este mes</p>
              <p className="card-value">{formatHours(summary.monthMinutes)}</p>
            </div>
          </div>

          <div className="grid grid-4" style={{ marginBottom: 24 }}>
            <div className="card">
              <p className="card-title">Ejercicios registrados</p>
              <p className="card-value">{summary.exerciseLogCount}</p>
            </div>
            <div className="card">
              <p className="card-title">Objetivos completados</p>
              <p className="card-value">{summary.goalsCompleted}</p>
            </div>
            <div className="card">
              <p className="card-title">Objetivos pendientes</p>
              <p className="card-value">{summary.goalsPending}</p>
            </div>
            <div className="card">
              <p className="card-title">Media / sesión</p>
              <p className="card-value">
                {formatHours(Math.round(summary.totalMinutes / summary.totalSessions))}
              </p>
            </div>
          </div>

          <div className="card">
            <p className="card-title" style={{ marginBottom: 14 }}>
              Sesiones recientes
            </p>
            <div className="table-wrap">
              <table className="data-table">
                <thead>
                  <tr>
                    <th>Fecha</th>
                    <th>Duración</th>
                    <th>Valoración</th>
                  </tr>
                </thead>
                <tbody>
                  {summary.recentSessions.map((s) => (
                    <tr key={s.id}>
                      <td>{new Date(s.date).toLocaleDateString("es-ES")}</td>
                      <td>{formatHours(s.duration_minutes)}</td>
                      <td>{s.overall_rating ? `${s.overall_rating}/10` : "—"}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </>
      ) : null}
    </div>
  );
}
