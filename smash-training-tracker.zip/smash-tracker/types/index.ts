export type TrainingType =
  | "Movimiento"
  | "Neutral"
  | "Advantage"
  | "Disadvantage"
  | "Combos"
  | "Recovery"
  | "Edgeguard"
  | "Defensa"
  | "Punish"
  | "Matchups"
  | "General"
  | "Otro";

export const TRAINING_TYPES: TrainingType[] = [
  "Movimiento",
  "Neutral",
  "Advantage",
  "Disadvantage",
  "Combos",
  "Recovery",
  "Edgeguard",
  "Defensa",
  "Punish",
  "Matchups",
  "General",
  "Otro",
];

export interface Profile {
  id: string;
  username: string | null;
  display_name: string | null;
  created_at: string;
  updated_at: string;
}

export interface TrainingSession {
  id: string;
  user_id: string;
  date: string;
  duration_minutes: number;
  character: string | null;
  training_type: TrainingType;
  overall_rating: number | null;
  notes: string | null;
  created_at: string;
  updated_at: string;
}

export interface Exercise {
  id: string;
  user_id: string;
  name: string;
  category: string | null;
  description: string | null;
  difficulty: number | null;
  created_at: string;
}

export interface ExerciseLog {
  id: string;
  user_id: string;
  session_id: string;
  exercise_id: string;
  repetitions: number | null;
  successful_attempts: number | null;
  failed_attempts: number | null;
  score: number | null;
  notes: string | null;
  created_at: string;
}

export interface Statistic {
  id: string;
  user_id: string;
  date: string;
  metric_name: string;
  metric_value: number;
  notes: string | null;
  created_at: string;
}

export interface Goal {
  id: string;
  user_id: string;
  title: string;
  description: string | null;
  target_value: number;
  current_value: number;
  unit: string | null;
  deadline: string | null;
  completed: boolean;
  created_at: string;
  updated_at: string;
}
