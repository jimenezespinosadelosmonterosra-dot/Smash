-- ============================================================================
-- SMASH TRAINING TRACKER — SUPABASE SCHEMA
-- Copia y pega este archivo completo en Supabase → SQL Editor → Run
-- ============================================================================

-- Extensión necesaria para gen_random_uuid()
create extension if not exists "pgcrypto";

-- ============================================================================
-- 1. PROFILES
-- ============================================================================
create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  username text unique,
  display_name text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

-- ============================================================================
-- 2. TRAINING SESSIONS
-- ============================================================================
create table if not exists public.training_sessions (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  date date not null default current_date,
  duration_minutes integer not null check (duration_minutes >= 0),
  character text,
  training_type text not null check (training_type in (
    'Movimiento','Neutral','Advantage','Disadvantage','Combos',
    'Recovery','Edgeguard','Defensa','Punish','Matchups','General','Otro'
  )),
  overall_rating smallint check (overall_rating between 1 and 10),
  notes text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create index if not exists idx_training_sessions_user_date
  on public.training_sessions (user_id, date desc);

-- ============================================================================
-- 3. EXERCISES (catálogo de ejercicios del usuario)
-- ============================================================================
create table if not exists public.exercises (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  name text not null,
  category text,
  description text,
  difficulty smallint check (difficulty between 1 and 5),
  created_at timestamptz not null default now()
);

create index if not exists idx_exercises_user on public.exercises (user_id);

-- ============================================================================
-- 4. EXERCISE LOGS (resultado de un ejercicio dentro de una sesión)
-- ============================================================================
create table if not exists public.exercise_logs (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  session_id uuid not null references public.training_sessions(id) on delete cascade,
  exercise_id uuid not null references public.exercises(id) on delete cascade,
  repetitions integer check (repetitions >= 0),
  successful_attempts integer check (successful_attempts >= 0),
  failed_attempts integer check (failed_attempts >= 0),
  score numeric,
  notes text,
  created_at timestamptz not null default now()
);

create index if not exists idx_exercise_logs_session on public.exercise_logs (session_id);
create index if not exists idx_exercise_logs_user on public.exercise_logs (user_id);

-- ============================================================================
-- 5. STATISTICS (métricas libres a lo largo del tiempo)
-- ============================================================================
create table if not exists public.statistics (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  date date not null default current_date,
  metric_name text not null,
  metric_value numeric not null,
  notes text,
  created_at timestamptz not null default now()
);

create index if not exists idx_statistics_user_date on public.statistics (user_id, date desc);
create index if not exists idx_statistics_metric on public.statistics (user_id, metric_name);

-- ============================================================================
-- 6. GOALS
-- ============================================================================
create table if not exists public.goals (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  title text not null,
  description text,
  target_value numeric not null,
  current_value numeric not null default 0,
  unit text,
  deadline date,
  completed boolean not null default false,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create index if not exists idx_goals_user on public.goals (user_id, completed);

-- ============================================================================
-- TRIGGERS: updated_at automático
-- ============================================================================
create or replace function public.set_updated_at()
returns trigger
language plpgsql
as $$
begin
  new.updated_at = now();
  return new;
end;
$$;

drop trigger if exists trg_profiles_updated_at on public.profiles;
create trigger trg_profiles_updated_at
  before update on public.profiles
  for each row execute function public.set_updated_at();

drop trigger if exists trg_sessions_updated_at on public.training_sessions;
create trigger trg_sessions_updated_at
  before update on public.training_sessions
  for each row execute function public.set_updated_at();

drop trigger if exists trg_goals_updated_at on public.goals;
create trigger trg_goals_updated_at
  before update on public.goals
  for each row execute function public.set_updated_at();

-- Auto-marcar objetivo como completado cuando current_value >= target_value
create or replace function public.check_goal_completion()
returns trigger
language plpgsql
as $$
begin
  if new.current_value >= new.target_value then
    new.completed = true;
  end if;
  return new;
end;
$$;

drop trigger if exists trg_goal_completion on public.goals;
create trigger trg_goal_completion
  before insert or update on public.goals
  for each row execute function public.check_goal_completion();

-- ============================================================================
-- TRIGGER: crear profile automáticamente al registrarse
-- ============================================================================
create or replace function public.handle_new_user()
returns trigger
language plpgsql
security definer set search_path = public
as $$
begin
  insert into public.profiles (id, username, display_name)
  values (new.id, split_part(new.email, '@', 1), split_part(new.email, '@', 1))
  on conflict (id) do nothing;
  return new;
end;
$$;

drop trigger if exists trg_on_auth_user_created on auth.users;
create trigger trg_on_auth_user_created
  after insert on auth.users
  for each row execute function public.handle_new_user();

-- ============================================================================
-- ROW LEVEL SECURITY
-- ============================================================================
alter table public.profiles enable row level security;
alter table public.training_sessions enable row level security;
alter table public.exercises enable row level security;
alter table public.exercise_logs enable row level security;
alter table public.statistics enable row level security;
alter table public.goals enable row level security;

-- PROFILES: el usuario solo ve/edita su propio perfil
drop policy if exists "profiles_select_own" on public.profiles;
create policy "profiles_select_own" on public.profiles
  for select using (auth.uid() = id);

drop policy if exists "profiles_update_own" on public.profiles;
create policy "profiles_update_own" on public.profiles
  for update using (auth.uid() = id);

drop policy if exists "profiles_insert_own" on public.profiles;
create policy "profiles_insert_own" on public.profiles
  for insert with check (auth.uid() = id);

-- TRAINING_SESSIONS
drop policy if exists "sessions_select_own" on public.training_sessions;
create policy "sessions_select_own" on public.training_sessions
  for select using (auth.uid() = user_id);

drop policy if exists "sessions_insert_own" on public.training_sessions;
create policy "sessions_insert_own" on public.training_sessions
  for insert with check (auth.uid() = user_id);

drop policy if exists "sessions_update_own" on public.training_sessions;
create policy "sessions_update_own" on public.training_sessions
  for update using (auth.uid() = user_id);

drop policy if exists "sessions_delete_own" on public.training_sessions;
create policy "sessions_delete_own" on public.training_sessions
  for delete using (auth.uid() = user_id);

-- EXERCISES
drop policy if exists "exercises_select_own" on public.exercises;
create policy "exercises_select_own" on public.exercises
  for select using (auth.uid() = user_id);

drop policy if exists "exercises_insert_own" on public.exercises;
create policy "exercises_insert_own" on public.exercises
  for insert with check (auth.uid() = user_id);

drop policy if exists "exercises_update_own" on public.exercises;
create policy "exercises_update_own" on public.exercises
  for update using (auth.uid() = user_id);

drop policy if exists "exercises_delete_own" on public.exercises;
create policy "exercises_delete_own" on public.exercises
  for delete using (auth.uid() = user_id);

-- EXERCISE_LOGS
drop policy if exists "exercise_logs_select_own" on public.exercise_logs;
create policy "exercise_logs_select_own" on public.exercise_logs
  for select using (auth.uid() = user_id);

drop policy if exists "exercise_logs_insert_own" on public.exercise_logs;
create policy "exercise_logs_insert_own" on public.exercise_logs
  for insert with check (auth.uid() = user_id);

drop policy if exists "exercise_logs_update_own" on public.exercise_logs;
create policy "exercise_logs_update_own" on public.exercise_logs
  for update using (auth.uid() = user_id);

drop policy if exists "exercise_logs_delete_own" on public.exercise_logs;
create policy "exercise_logs_delete_own" on public.exercise_logs
  for delete using (auth.uid() = user_id);

-- STATISTICS
drop policy if exists "statistics_select_own" on public.statistics;
create policy "statistics_select_own" on public.statistics
  for select using (auth.uid() = user_id);

drop policy if exists "statistics_insert_own" on public.statistics;
create policy "statistics_insert_own" on public.statistics
  for insert with check (auth.uid() = user_id);

drop policy if exists "statistics_update_own" on public.statistics;
create policy "statistics_update_own" on public.statistics
  for update using (auth.uid() = user_id);

drop policy if exists "statistics_delete_own" on public.statistics;
create policy "statistics_delete_own" on public.statistics
  for delete using (auth.uid() = user_id);

-- GOALS
drop policy if exists "goals_select_own" on public.goals;
create policy "goals_select_own" on public.goals
  for select using (auth.uid() = user_id);

drop policy if exists "goals_insert_own" on public.goals;
create policy "goals_insert_own" on public.goals
  for insert with check (auth.uid() = user_id);

drop policy if exists "goals_update_own" on public.goals;
create policy "goals_update_own" on public.goals
  for update using (auth.uid() = user_id);

drop policy if exists "goals_delete_own" on public.goals;
create policy "goals_delete_own" on public.goals
  for delete using (auth.uid() = user_id);

-- ============================================================================
-- FIN DEL SCRIPT
-- ============================================================================
