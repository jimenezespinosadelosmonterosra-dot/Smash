import { supabase } from "@/lib/supabaseClient";
import type { Goal } from "@/types";

export type NewGoal = Omit<
  Goal,
  "id" | "user_id" | "created_at" | "updated_at" | "completed"
>;

export async function listGoals(params?: { onlyPending?: boolean }) {
  let query = supabase
    .from("goals")
    .select("*")
    .order("deadline", { ascending: true, nullsFirst: false });
  if (params?.onlyPending) query = query.eq("completed", false);
  const { data, error } = await query;
  return { data: (data as Goal[]) ?? [], error };
}

export async function createGoal(goal: NewGoal) {
  const { data: userData } = await supabase.auth.getUser();
  const user_id = userData.user?.id;
  if (!user_id) return { data: null, error: { message: "No hay sesión activa" } };

  const { data, error } = await supabase
    .from("goals")
    .insert([{ ...goal, user_id, current_value: 0 }])
    .select()
    .single();
  return { data: data as Goal | null, error };
}

export async function updateGoal(id: string, updates: Partial<Goal>) {
  const { data, error } = await supabase
    .from("goals")
    .update(updates)
    .eq("id", id)
    .select()
    .single();
  return { data: data as Goal | null, error };
}

export async function deleteGoal(id: string) {
  const { error } = await supabase.from("goals").delete().eq("id", id);
  return { error };
}
