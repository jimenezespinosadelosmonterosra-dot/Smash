import { supabase } from "@/lib/supabaseClient";
import type { Statistic } from "@/types";

export type NewStatistic = Omit<Statistic, "id" | "user_id" | "created_at">;

export async function listStatistics(params?: {
  metricName?: string;
  from?: string;
  to?: string;
}) {
  let query = supabase.from("statistics").select("*").order("date");
  if (params?.metricName) query = query.eq("metric_name", params.metricName);
  if (params?.from) query = query.gte("date", params.from);
  if (params?.to) query = query.lte("date", params.to);
  const { data, error } = await query;
  return { data: (data as Statistic[]) ?? [], error };
}

export async function createStatistic(stat: NewStatistic) {
  const { data: userData } = await supabase.auth.getUser();
  const user_id = userData.user?.id;
  if (!user_id) return { data: null, error: { message: "No hay sesión activa" } };

  const { data, error } = await supabase
    .from("statistics")
    .insert([{ ...stat, user_id }])
    .select()
    .single();
  return { data: data as Statistic | null, error };
}

export async function deleteStatistic(id: string) {
  const { error } = await supabase.from("statistics").delete().eq("id", id);
  return { error };
}
