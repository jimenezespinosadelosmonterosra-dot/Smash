import { supabase } from "@/lib/supabaseClient";
import type { Exercise, ExerciseLog } from "@/types";

export type NewExercise = Omit<Exercise, "id" | "user_id" | "created_at">;
export type NewExerciseLog = Omit<ExerciseLog, "id" | "user_id" | "created_at">;

export async function listExercises(params?: {
  category?: string;
  search?: string;
}) {
  let query = supabase.from("exercises").select("*").order("name");
  if (params?.category) query = query.eq("category", params.category);
  if (params?.search) query = query.ilike("name", `%${params.search}%`);
  const { data, error } = await query;
  return { data: (data as Exercise[]) ?? [], error };
}

export async function createExercise(exercise: NewExercise) {
  const { data: userData } = await supabase.auth.getUser();
  const user_id = userData.user?.id;
  if (!user_id) return { data: null, error: { message: "No hay sesión activa" } };

  const { data, error } = await supabase
    .from("exercises")
    .insert([{ ...exercise, user_id }])
    .select()
    .single();
  return { data: data as Exercise | null, error };
}

export async function updateExercise(id: string, updates: Partial<NewExercise>) {
  const { data, error } = await supabase
    .from("exercises")
    .update(updates)
    .eq("id", id)
    .select()
    .single();
  return { data: data as Exercise | null, error };
}

export async function deleteExercise(id: string) {
  const { error } = await supabase.from("exercises").delete().eq("id", id);
  return { error };
}

export async function listExerciseLogsForSession(sessionId: string) {
  const { data, error } = await supabase
    .from("exercise_logs")
    .select("*, exercises(name, category)")
    .eq("session_id", sessionId)
    .order("created_at");
  return { data: data ?? [], error };
}

export async function createExerciseLog(log: NewExerciseLog) {
  const { data: userData } = await supabase.auth.getUser();
  const user_id = userData.user?.id;
  if (!user_id) return { data: null, error: { message: "No hay sesión activa" } };

  const { data, error } = await supabase
    .from("exercise_logs")
    .insert([{ ...log, user_id }])
    .select()
    .single();
  return { data: data as ExerciseLog | null, error };
}

export async function deleteExerciseLog(id: string) {
  const { error } = await supabase.from("exercise_logs").delete().eq("id", id);
  return { error };
}
