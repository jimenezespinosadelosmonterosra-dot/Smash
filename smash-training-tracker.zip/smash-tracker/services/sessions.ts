import { supabase } from "@/lib/supabaseClient";
import type { TrainingSession } from "@/types";

export type NewTrainingSession = Omit<
  TrainingSession,
  "id" | "user_id" | "created_at" | "updated_at"
>;

export async function listSessions(params?: {
  from?: string;
  to?: string;
  character?: string;
  trainingType?: string;
  search?: string;
  page?: number;
  pageSize?: number;
}) {
  const page = params?.page ?? 0;
  const pageSize = params?.pageSize ?? 20;

  let query = supabase
    .from("training_sessions")
    .select("*", { count: "exact" })
    .order("date", { ascending: false })
    .range(page * pageSize, page * pageSize + pageSize - 1);

  if (params?.from) query = query.gte("date", params.from);
  if (params?.to) query = query.lte("date", params.to);
  if (params?.character) query = query.eq("character", params.character);
  if (params?.trainingType)
    query = query.eq("training_type", params.trainingType);
  if (params?.search) query = query.ilike("notes", `%${params.search}%`);

  const { data, error, count } = await query;
  return { data: (data as TrainingSession[]) ?? [], error, count: count ?? 0 };
}

export async function getSession(id: string) {
  const { data, error } = await supabase
    .from("training_sessions")
    .select("*")
    .eq("id", id)
    .single();
  return { data: data as TrainingSession | null, error };
}

export async function createSession(session: NewTrainingSession) {
  const { data: userData } = await supabase.auth.getUser();
  const user_id = userData.user?.id;
  if (!user_id) return { data: null, error: { message: "No hay sesión activa" } };

  const { data, error } = await supabase
    .from("training_sessions")
    .insert([{ ...session, user_id }])
    .select()
    .single();

  return { data: data as TrainingSession | null, error };
}

export async function updateSession(
  id: string,
  updates: Partial<NewTrainingSession>
) {
  const { data, error } = await supabase
    .from("training_sessions")
    .update(updates)
    .eq("id", id)
    .select()
    .single();
  return { data: data as TrainingSession | null, error };
}

export async function deleteSession(id: string) {
  const { error } = await supabase.from("training_sessions").delete().eq("id", id);
  return { error };
}
