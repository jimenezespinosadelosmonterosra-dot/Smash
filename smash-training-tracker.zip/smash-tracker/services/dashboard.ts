import { supabase } from "@/lib/supabaseClient";
import type { TrainingSession } from "@/types";

/**
 * Calcula los números reales del dashboard directamente desde Supabase.
 * No hay datos inventados: si no hay sesiones, todo vuelve en 0.
 */
export async function getDashboardSummary() {
  const { data: sessions, error } = await supabase
    .from("training_sessions")
    .select("id, date, duration_minutes, overall_rating")
    .order("date", { ascending: false });

  if (error || !sessions) {
    return { data: null, error };
  }

  const list = sessions as Pick<
    TrainingSession,
    "id" | "date" | "duration_minutes" | "overall_rating"
  >[];

  const now = new Date();
  const startOfWeek = new Date(now);
  startOfWeek.setDate(now.getDate() - now.getDay());
  startOfWeek.setHours(0, 0, 0, 0);

  const startOfMonth = new Date(now.getFullYear(), now.getMonth(), 1);

  const totalSessions = list.length;
  const totalMinutes = list.reduce((sum, s) => sum + (s.duration_minutes || 0), 0);
  const weekMinutes = list
    .filter((s) => new Date(s.date) >= startOfWeek)
    .reduce((sum, s) => sum + (s.duration_minutes || 0), 0);
  const monthMinutes = list
    .filter((s) => new Date(s.date) >= startOfMonth)
    .reduce((sum, s) => sum + (s.duration_minutes || 0), 0);

  const [{ count: exerciseLogCount }, { count: goalsCompleted }, { count: goalsPending }] =
    await Promise.all([
      supabase.from("exercise_logs").select("*", { count: "exact", head: true }),
      supabase
        .from("goals")
        .select("*", { count: "exact", head: true })
        .eq("completed", true),
      supabase
        .from("goals")
        .select("*", { count: "exact", head: true })
        .eq("completed", false),
    ]);

  return {
    error: null,
    data: {
      totalSessions,
      totalMinutes,
      weekMinutes,
      monthMinutes,
      exerciseLogCount: exerciseLogCount ?? 0,
      goalsCompleted: goalsCompleted ?? 0,
      goalsPending: goalsPending ?? 0,
      recentSessions: list.slice(0, 5),
    },
  };
}
