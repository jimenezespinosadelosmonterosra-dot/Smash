# Smash Training Tracker

Aplicación web real (no demo) para registrar y analizar tu progreso de entrenamiento en Super Smash Bros. Next.js 14 (App Router) + Supabase (Auth, PostgreSQL, RLS).

## A. Arquitectura

```
app/
  layout.tsx              layout raíz + AuthProvider
  page.tsx                redirige a /dashboard o /login según sesión
  login/page.tsx
  reset-password/page.tsx
  (protected)/layout.tsx   protege rutas: sin sesión -> /login
  (protected)/dashboard/
  (protected)/training/    nueva sesión
  (protected)/history/     listado, filtros, edición, borrado
  (protected)/progress/    estadísticas + gráficas (Chart.js)
  (protected)/goals/       objetivos con barra de progreso
  (protected)/exercises/   catálogo de ejercicios
  (protected)/settings/    perfil, contraseña, export/backup, importador
components/                Sidebar, ImportSessions
services/                  una función por entidad -> llamadas a Supabase (sessions, exercises, goals, statistics, dashboard)
hooks/useAuth.tsx           contexto de autenticación (Supabase Auth)
lib/supabaseClient.ts       cliente único de Supabase (anon key)
types/index.ts              tipos TypeScript de todas las entidades
supabase/schema.sql          SQL completo: tablas, RLS, triggers
```

La UI nunca guarda datos en `localStorage`. Todo (sesiones, ejercicios, objetivos, estadísticas) vive en PostgreSQL vía Supabase, protegido con RLS. Las páginas protegidas comprueban la sesión con `supabase.auth` y redirigen a `/login` si no existe.

## B. SQL completo

Está en `supabase/schema.sql`. Incluye:
- Las 6 tablas pedidas (`profiles`, `training_sessions`, `exercises`, `exercise_logs`, `statistics`, `goals`) con UUID, foreign keys a `auth.users`, timestamps e índices.
- Trigger que crea automáticamente el `profile` al registrarse un usuario.
- Trigger que actualiza `updated_at`.
- Trigger que marca un objetivo como `completed` cuando `current_value >= target_value`.
- RLS activado en las 6 tablas con políticas `SELECT/INSERT/UPDATE/DELETE` basadas en `auth.uid() = user_id` (nunca `USING (true)`).

## C. Instalación

1. Requisitos: Node.js 18+ y una cuenta gratuita en [supabase.com](https://supabase.com).
2. Crea un proyecto en Supabase.
3. Ve a **SQL Editor** y ejecuta el contenido completo de `supabase/schema.sql`.
4. Ve a **Project Settings → API** y copia `Project URL` y `anon public key`.
5. Copia `.env.example` como `.env.local` y rellena esos dos valores:
   ```
   NEXT_PUBLIC_SUPABASE_URL=https://tu-proyecto.supabase.co
   NEXT_PUBLIC_SUPABASE_ANON_KEY=tu-anon-key
   ```
6. Instala dependencias:
   ```bash
   npm install
   ```
7. Arranca en local:
   ```bash
   npm run dev
   ```
   Abre http://localhost:3000

8. En Supabase → **Authentication → Providers**, asegúrate de que "Email" está activado. En **Authentication → URL Configuration** añade `http://localhost:3000/reset-password` como Redirect URL (y la URL de producción cuando despliegues).

9. Crea tu único usuario: como el auto-registro público no tiene un formulario en esta app (según lo pedido), créalo desde Supabase → **Authentication → Users → Add user**, con tu email y contraseña. El trigger `handle_new_user` te creará el `profile` automáticamente.

## D. Variables de entorno

Solo dos, ambas públicas por diseño (la anon key está pensada para el frontend y las políticas RLS son la barrera de seguridad real):

- `NEXT_PUBLIC_SUPABASE_URL`
- `NEXT_PUBLIC_SUPABASE_ANON_KEY`

**Nunca** se usa ni se expone la `service_role key` en este proyecto.

## E. Seguridad (RLS)

Cada tabla con datos personales tiene RLS activado y 4 políticas (`select/insert/update/delete`) que comparan `auth.uid()` con el `user_id` de la fila. Ningún usuario puede leer ni escribir datos de otro. Las contraseñas nunca se guardan en tablas propias: todo pasa por `supabase.auth` (login, registro, reseteo, cambio de contraseña).

## F. Checklist de lo implementado

- [x] Login (Supabase Auth)
- [x] Logout
- [x] Recuperación de contraseña (`resetPasswordForEmail`)
- [x] Protección de rutas (`(protected)/layout.tsx`)
- [x] Supabase conectado
- [x] PostgreSQL
- [x] RLS en las 6 tablas
- [x] Crear / editar / eliminar sesiones
- [x] Historial con filtros, búsqueda y paginación
- [x] Ejercicios (CRUD + filtro por categoría)
- [x] Objetivos con progreso y celebración al completarse
- [x] Gráficas reales con Chart.js (volumen, valoraciones) y rango 7/30/90/365/todo
- [x] Exportación CSV, JSON y backup completo
- [x] Importador Excel/CSV con mapeo de columnas, preview y errores por fila
- [x] Responsive (móvil 320px+, tablet, desktop) con sidebar colapsable
- [x] Manejo de errores en cada llamada a Supabase
- [x] Estilo dark gaming/esports (no plantilla genérica)

**No implementado en esta primera entrega** (documentado explícitamente, no simulado):
- Registro de `exercise_logs` desde la UI de una sesión concreta (la tabla y el servicio `services/exercises.ts` ya existen y están listos; falta la pantalla de detalle de sesión para usarlos).
- Tabla `statistics` sin pantalla propia todavía (servicio `services/statistics.ts` ya implementado).
- Roles `user`/`admin` (la arquitectura lo permite añadiendo una columna `role` en `profiles` y comprobándola en políticas RLS, nunca solo en frontend).

## G. Deployment (Vercel)

1. Sube el proyecto a un repositorio Git.
2. En Vercel: **New Project** → importa el repo.
3. En **Environment Variables** añade `NEXT_PUBLIC_SUPABASE_URL` y `NEXT_PUBLIC_SUPABASE_ANON_KEY` (mismos valores que en `.env.local`).
4. Deploy.
5. En Supabase → **Authentication → URL Configuration**, añade la URL de producción y `https://tu-dominio.vercel.app/reset-password` como Redirect URL.
6. Si usas un dominio propio, configúralo en Vercel → **Domains** y actualiza también las Redirect URLs en Supabase.

## Importación del Excel

En **Configuración → Importar desde Excel/CSV** puedes subir tu tracker actual (`.xlsx` o `.csv`), mapear tus columnas a los campos de `training_sessions`, previsualizar las primeras filas y ver errores fila por fila antes de confirmar la importación.
